<?php
/*
	Plugin Name: LBMN Projects
	Plugin URI: http://lumberman.co.uk/
	Description: Work projects, portfolio content type
	Version: 0.2
	Author: Lumberman Themes
	Author URI: http://lumberman.co.uk/
*/

// Exit if called directly
defined( 'ABSPATH' ) or die( "Cannot access pages directly." );

/* Set up the post types. */

// Register Custom Post Type
function lbmn_portfolio() {

	$labels = array(
		'name'                => _x( 'Projects', 'Post Type General Name', 'lbmn' ),
		'singular_name'       => _x( 'Project', 'Post Type Singular Name', 'lbmn' ),
		'menu_name'           => __( 'Projects', 'lbmn' ),
		'parent_item_colon'   => __( 'Parent Project', 'lbmn' ),
		'all_items'           => __( 'All Projects', 'lbmn' ),
		'view_item'           => __( 'View Project', 'lbmn' ),
		'add_new_item'        => __( 'Add New Project', 'lbmn' ),
		'add_new'             => __( 'New Project', 'lbmn' ),
		'edit_item'           => __( 'Edit Project', 'lbmn' ),
		'update_item'         => __( 'Update Project', 'lbmn' ),
		'search_items'        => __( 'Search projects', 'lbmn' ),
		'not_found'           => __( 'No projects found', 'lbmn' ),
		'not_found_in_trash'  => __( 'No projects found in Trash', 'lbmn' ),
	);
	$rewrite = array(
		'slug'                => 'portfolio',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);
	$args = array(
		'label'               => __( 'project', 'lbmn' ),
		'description'         => __( 'Portfolio, works, projects', 'lbmn' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments', ),
		'taxonomies'          => array( 'lbmn_project_type', 'lbmn_project_attribute' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 20,
		'menu_icon'           => 'dashicons-portfolio',
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'rewrite'             => $rewrite,
		'capability_type'     => 'page',
	);
	lbmn_enable_visualcomposer_for_projects();
	register_post_type( 'lbmn_project', $args );

}

// Hook into the 'init' action
add_action( 'init', 'lbmn_portfolio', 0 );


// Add Visual Composer compatability
function lbmn_enable_visualcomposer_for_projects(){
	$vc_post_types_option = 'wpb_js_content_types';
	$vc_supported_post_types = get_option($vc_post_types_option);
	if ( is_array( $vc_supported_post_types ) ) {
		if(!in_array('lbmn_project', $vc_supported_post_types)){
			$vc_supported_post_types[] = 'lbmn_project';
			update_option($vc_post_types_option, $vc_supported_post_types);
		}
	}
}



/**
* ----------------------------------------------------------------------
* Project Type Taxonomy
*/

// Register Custom Taxonomy
function lbmn_project_type_taxonomy()  {

	$labels = array(
		'name'                       => _x( 'Project Types', 'Taxonomy General Name', 'lbmn' ),
		'singular_name'              => _x( 'Project Type', 'Taxonomy Singular Name', 'lbmn' ),
		'menu_name'                  => __( 'Project Types', 'lbmn' ),
		'all_items'                  => __( 'All Types', 'lbmn' ),
		'parent_item'                => __( 'Parent Type', 'lbmn' ),
		'parent_item_colon'          => __( 'Parent Types:', 'lbmn' ),
		'new_item_name'              => __( 'New Project Type', 'lbmn' ),
		'add_new_item'               => __( 'Add New Project Type', 'lbmn' ),
		'edit_item'                  => __( 'Edit Type', 'lbmn' ),
		'update_item'                => __( 'Update Type', 'lbmn' ),
		'separate_items_with_commas' => __( 'Separate project types with commas', 'lbmn' ),
		'search_items'               => __( 'Search project types', 'lbmn' ),
		'add_or_remove_items'        => __( 'Add or remove project type', 'lbmn' ),
		'choose_from_most_used'      => __( 'Choose from the most used project types', 'lbmn' ),
	);
	$rewrite = array(
		'slug'                       => 'project-type',
		'with_front'                 => true,
		'hierarchical'               => false,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'query_var'                  => 'project_type',
		'rewrite'                    => $rewrite,
	);
	register_taxonomy( 'lbmn_project_type', 'lbmn_project', $args );
	register_taxonomy_for_object_type( 'lbmn_project_type', 'lbmn_project' );
}

// Hook into the 'init' action
add_action( 'init', 'lbmn_project_type_taxonomy', 0 );

/**
* ----------------------------------------------------------------------
* Project Attributes Taxonomy
*/

// Register Custom Taxonomy
function lbmn_project_attributes_taxonomy()  {

	$labels = array(
		'name'                       => _x( 'Project Attributes', 'Taxonomy General Name', 'lbmn' ),
		'singular_name'              => _x( 'Project Attribute', 'Taxonomy Singular Name', 'lbmn' ),
		'menu_name'                  => __( 'Project Attributes', 'lbmn' ),
		'all_items'                  => __( 'All Attributes', 'lbmn' ),
		'parent_item'                => __( 'Parent Attribute', 'lbmn' ),
		'parent_item_colon'          => __( 'Parent Attributes:', 'lbmn' ),
		'new_item_name'              => __( 'New Project Attribute', 'lbmn' ),
		'add_new_item'               => __( 'Add New Project Attribute', 'lbmn' ),
		'edit_item'                  => __( 'Edit Attribute', 'lbmn' ),
		'update_item'                => __( 'Update Attribute', 'lbmn' ),
		'separate_items_with_commas' => __( 'Separate project attributes with commas', 'lbmn' ),
		'search_items'               => __( 'Search project attributes', 'lbmn' ),
		'add_or_remove_items'        => __( 'Add or remove project attribute', 'lbmn' ),
		'choose_from_most_used'      => __( 'Choose from the most used project attributes', 'lbmn' ),
	);
	$rewrite = array(
		'slug'                       => 'project-attribute',
		'with_front'                 => true,
		'hierarchical'               => false,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'query_var'                  => 'project_attribute',
		'rewrite'                    => $rewrite,
	);
	register_taxonomy( 'lbmn_project_attribute', 'lbmn_project', $args );
	register_taxonomy_for_object_type( 'lbmn_project_attribute', 'lbmn_project' );

}

// Hook into the 'init' action
add_action( 'init', 'lbmn_project_attributes_taxonomy', 0 );


/**
* ----------------------------------------------------------------------
* Additional posts grid column with shortcode
* http://wp.tutsplus.com/tutorials/creative-coding/add-a-custom-column-in-posts-and-custom-post-types-admin-screen/
*/

/**
* ----------------------------------------------------------------------
* Add custom meta boxes with project settings
*
* Uses 'Meta Box' plugin by http://www.deluxeblogtips.com/
* See /plugins/meta-box/demo/demo.php for available controls
*/

$prefix = 'lbmn_project_';
global $meta_boxes;

if ( !isset($meta_boxes) ) {
	$meta_boxes = array();
}

$meta_boxes[] = array(
	// Meta box id, UNIQUE per meta box. Optional since 4.1.5
	'id' => 'lbmn-project-settings',

	// Meta box title - Will appear at the drag and drop handle bar. Required.
	'title' => __( 'Project Card Design (on project index page)', 'lbmn' ),

	// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
	'pages' => array( 'lbmn_project' ),

	// Where the meta box appear: normal (default), advanced, side. Optional.
	'context' => 'normal',

	// Order of meta box: high (default), low. Optional.
	'priority' => 'low',

	// Auto save: true, false (default). Optional.
	'autosave' => true,

	// List of meta fields
	'fields' => array(
		// HEADING
		// array(
		// 	'type' => 'heading',
		// 	'name' => __( 'Custom project card design.', 'lbmn' ),
		// 	'id'   => "{$prefix}heading", // Not used but needed for plugin
		// ),
		// COLOR
		array(
			'name' => __( 'Background color', 'lbmn' ),
			'id'   => "{$prefix}bgcolor",
			'type' => 'color',
		),
		// COLOR
		array(
			'name' => __( 'Text color', 'lbmn' ),
			'id'   => "{$prefix}textcolor",
			'type' => 'color',
		),
	),
);

$meta_boxes[] = array(
	// Meta box id, UNIQUE per meta box. Optional since 4.1.5
	'id' => 'lbmn-project-side-settings',

	// Meta box title - Will appear at the drag and drop handle bar. Required.
	'title' => __( 'Page Attributes', 'lbmn' ),

	// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
	'pages' => array( 'lbmn_project' ),

	// Where the meta box appear: normal (default), advanced, side. Optional.
	'context' => 'side',

	// Order of meta box: high (default), low. Optional.
	'priority' => 'high',

	// Auto save: true, false (default). Optional.
	'autosave' => true,

	// List of meta fields
	'fields' => array(
		// SELECT BOX
		array(
			'name'     => __( 'Template', 'rwmb' ),
			'id'       => "{$prefix}page_template",
			'type'     => 'select',
			'options'  => array(
				'none' => __( 'Full width', 'rwmb' ),
				'left' => __( 'Sidebar - Left', 'rwmb' ),
				'right' => __( 'Sidebar - Right', 'rwmb' ),
			),
			'std'         => 'none',
			// 'placeholder' => __( 'Select an Item', 'rwmb' ),
		),
	),
);

/**
 * Register meta boxes
 *
 * @return void
 */
function lbmn_register_project_metaboxes()
{
	// Make sure there's no errors when the plugin is deactivated or during upgrade
	if ( !class_exists( 'RW_Meta_Box' ) )
		return;

	global $meta_boxes;
	foreach ( $meta_boxes as $meta_box )
	{
		new RW_Meta_Box( $meta_box );
	}
}

// Originally meta-box plugin propose to hook to 'admin_init'
// to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// but it doesn't work in this case when we call it from another plugin
// add_action( 'admin_init', 'lbmn_register_sectionslider_metaboxes' );

// Make sure that meta-box plugin is loaded before using it (original 'admin_init' hook is to early)
add_action( 'plugins_loaded', 'lbmn_register_project_metaboxes', 0 );
